package com.xworkz.dao;

import com.xworkz.entity.VaccineEntity;

public interface VaccineDAO {

	public boolean saveVaccineOTP(VaccineEntity vaccineEntity);

	public VaccineEntity findVaccineOTP(String otp);

}
