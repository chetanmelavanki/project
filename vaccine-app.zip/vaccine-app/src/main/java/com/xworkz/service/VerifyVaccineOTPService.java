package com.xworkz.service;

import com.xworkz.dto.VaccineVerifyOTPDTO;

public interface VerifyVaccineOTPService {

	public boolean validateOTP(String otp);

	public VaccineVerifyOTPDTO getVaccineOTP(String otp);

}
